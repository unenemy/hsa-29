require 'aws-sdk-s3'

def lambda_handler(event:, context:)
  # Get the source and destination bucket names and file key from the event
  source_bucket = event['Records'][0]['s3']['bucket']['name']
  destination_bucket = 'hsa-29-output'  # Replace with your destination bucket name
  file_key = event['Records'][0]['s3']['object']['key']

  # Initialize the S3 client
  s3 = Aws::S3::Client.new

  # Copy the file from the source bucket to the destination bucket
  s3.copy_object(
    bucket: destination_bucket,
    copy_source: "#{source_bucket}/#{file_key}",
    key: file_key
  )

  puts "File #{file_key} copied from #{source_bucket} to #{destination_bucket}"
end